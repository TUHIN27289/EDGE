// src/hooks/useFetchData.js
import { useState, useEffect } from 'react';
import { fetchData } from '../services/api';

const useFetchData = (url) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAndSetData = async () => {
      try {
        const result = await fetchData(url);
        setData(result);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAndSetData();
  }, [url]);

  return { data, loading, error };
};

export default useFetchData;
