import React, { useRef } from 'react';

function App() {
  const textRef = useRef();

  const handleChangeText = () => {
    if (textRef.current) {
      textRef.current.textContent = "The text has been updated!";
      textRef.current.style.color = "red"; // Change text color to red
    }
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>React useRef Example</h1>
      <p ref={textRef} style={{ fontSize: '18px', marginBottom: '20px' }}>
        This is the original text.
      </p>
      <button
        onClick={handleChangeText}
        style={{
          padding: '10px 20px',
          fontSize: '16px',
          backgroundColor: '#007BFF',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
      >
        Change Text
      </button>
    </div>
  );
}

export default App;
