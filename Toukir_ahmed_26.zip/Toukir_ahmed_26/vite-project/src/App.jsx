import React from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import './App.css';

const App = () => {
  return (
    <div>
      <Navbar />
      <div className="content">
        <h1>Welcome to My Website</h1>
        <p>This is a simple website with a modern navbar, dropdown, and footer.</p>
      </div>
      <Footer />
    </div>
  );
};

export default App;
