import React, { useState } from 'react';
import './Navbar.css';

const Navbar = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">My Website</div>
      <div className="navbar-links">
        <a href="#home">Home</a>
        <a href="#about">About</a>
        <div className="dropdown">
          <button onClick={toggleDropdown} className="dropdown-button">
            Services
          </button>
          {isDropdownOpen && (
            <div className="dropdown-menu">
              <a href="#service1">Service 1</a>
              <a href="#service2">Service 2</a>
              <a href="#service3">Service 3</a>
            </div>
          )}
        </div>
        <a href="#contact">Contact</a>
      </div>
    </nav>
  );
};

export default Navbar;
